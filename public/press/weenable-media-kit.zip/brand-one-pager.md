# WeEnable — Media One-Pager (placeholder)

WeEnable (formerly Creating Abilities) is a global movement removing the barriers
between ability and opportunity, across eight programs: disability, adaptive sport,
seniors, caregivers, employment, digital & AI accessibility, policy, and the arts.

- Tagline: "Ability was never the barrier."
- Brand colors: Ink #100D08, Paper #FDFAF6, Coral #E27641, Teal #00B2BD.
- Press contact: press@weenable.org

PLACEHOLDER — replace with the approved media kit (logos, fact sheet, headshots)
before public launch.
